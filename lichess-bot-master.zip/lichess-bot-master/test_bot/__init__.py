"""pytest won't search `test_bot/` if there is no `__init__.py` file."""
